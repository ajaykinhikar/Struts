package mybeans;

public class LoginAction 
{
	private String userid;
	private String pswd;
	private String loginstatus;
	
	public LoginAction()
	{
		userid="";
		pswd="";
		loginstatus="fail";
	}
	
	public String execute()
	{
		
		if(userid.equals("ethan") && pswd.equals("mission"))
			loginstatus="success";
		
		return loginstatus;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getPswd() {
		return pswd;
	}

	public void setPswd(String pswd) {
		this.pswd = pswd;
	}

	public String getLoginstatus() {
		return loginstatus;
	}

	public void setLoginstatus(String loginstatus) {
		this.loginstatus = loginstatus;
	}
	
	
	

}

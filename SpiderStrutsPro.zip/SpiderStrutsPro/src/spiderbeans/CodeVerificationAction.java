package spiderbeans;

import com.opensymphony.xwork2.ActionSupport;

public class CodeVerificationAction extends ActionSupport
{
	private String username;
	private String code;
	
	private String status;
	
	public CodeVerificationAction()
	{
		username="";
		code="";
		status="fail";
	}
	
	public String execute()
	{
		if(code.equals("mission786"))
			status="success";
		
		return status;
	}
	
	
	public void validate()
	{
		if(username.length()==0)
			addFieldError("username","Enter name");
		
		if(code.length()==0)
			addFieldError("code","Enter Code");
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	

}
